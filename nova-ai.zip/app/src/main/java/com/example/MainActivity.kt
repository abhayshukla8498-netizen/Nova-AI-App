@file:Suppress("DEPRECATION")
package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.RoutineTask
import com.example.ui.*
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = MinimalBg,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    NovaApp(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
}

@Composable
fun NovaApp(
    modifier: Modifier = Modifier,
    viewModel: NovaViewModel = viewModel()
) {
    val context = LocalContext.current

    // Check for incoming background voice trigger intent
    val activity = context as? ComponentActivity
    LaunchedEffect(key1 = activity?.intent) {
        val intent = activity?.intent
        if (intent != null && intent.action == "com.example.voice.intent.START_VOICE") {
            viewModel.startListening()
            intent.action = null
        }
    }

    val coroutineScope = rememberCoroutineScope()
    val activeTab by viewModel.activeTab.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isProcessing by viewModel.isProcessing.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val isActivated by viewModel.isActivated.collectAsState()

    val isListening by viewModel.voiceManager.isListening.collectAsState()
    val soundLevel by viewModel.voiceManager.soundLevel.collectAsState()
    val speechText by viewModel.voiceManager.speechText.collectAsState()
    val speechError by viewModel.voiceManager.error.collectAsState()

    var showAddTaskDialog by remember { mutableStateOf(false) }
    var showVoiceSettingsDialog by remember { mutableStateOf(false) }

    // Speech recognition permission request flow
    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.startListening()
        } else {
            Toast.makeText(
                context,
                "Microphone permission is required for voice commands. Simulated mode active.",
                Toast.LENGTH_LONG
            ).show()
            // Fallback: trigger simulated listening state
            viewModel.startListening()
        }
    }

    val onMicOrbClicked = {
        if (isListening) {
            viewModel.stopListening()
        } else {
            val micPermission = Manifest.permission.RECORD_AUDIO
            if (ContextCompat.checkSelfPermission(context, micPermission) == PackageManager.PERMISSION_GRANTED) {
                viewModel.startListening()
            } else {
                voiceLauncher.launch(micPermission)
            }
        }
    }

    Box(
        modifier = modifier.fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_app_ui_bg_1782633644542),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        // Elegant glassmorphism dark overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A).copy(alpha = 0.35f))
        )

        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Upper Professional Status bar
            NovaHeader(
                isProcessing = isProcessing || isListening,
                onSettingsClick = {
                    showVoiceSettingsDialog = true
                }
            )

                // Tab Row selector
                TabRow(
                    selectedTabIndex = activeTab,
                    containerColor = Color.Transparent,
                    contentColor = Color(0xFF818CF8),
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                            color = Color(0xFF818CF8)
                        )
                    },
                    divider = {}
                ) {
                    Tab(
                        selected = activeTab == 0,
                        onClick = { viewModel.setActiveTab(0) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = null,
                                    tint = if (activeTab == 0) Color(0xFF818CF8) else Color.White.copy(alpha = 0.5f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "AI Assistant",
                                    fontWeight = FontWeight.Bold,
                                    color = if (activeTab == 0) Color.White else Color.White.copy(alpha = 0.6f)
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_assistant")
                    )
                    Tab(
                        selected = activeTab == 1,
                        onClick = { viewModel.setActiveTab(1) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.DateRange,
                                    contentDescription = null,
                                    tint = if (activeTab == 1) Color(0xFF818CF8) else Color.White.copy(alpha = 0.5f),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    "Smart Routine",
                                    fontWeight = FontWeight.Bold,
                                    color = if (activeTab == 1) Color.White else Color.White.copy(alpha = 0.6f)
                                )
                            }
                        },
                        modifier = Modifier.testTag("tab_routine")
                    )
                }

                Divider(
                    color = Color.White.copy(alpha = 0.15f),
                    thickness = 1.dp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                // Main screens content
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (activeTab == 0) {
                        AssistantView(
                            chatMessages = chatMessages,
                            isProcessing = isProcessing,
                            isListening = isListening,
                            soundLevel = soundLevel,
                            speechText = speechText,
                            speechError = speechError,
                            onMicClicked = onMicOrbClicked,
                            onSendMessage = { text -> viewModel.handleUserMessage(text) },
                            onSuggestionClicked = { text -> viewModel.handleUserMessage(text) },
                            viewModel = viewModel
                        )
                    } else {
                        RoutinePlannerView(
                            tasks = allTasks,
                            onToggleComplete = { task -> viewModel.toggleTask(task) },
                            onDeleteTask = { task -> viewModel.deleteTask(task) },
                            onClearCompleted = { viewModel.clearCompleted() },
                            onAddTaskClicked = { showAddTaskDialog = true }
                        )
                    }
                }
            }
        }

    // Modal dialog for manual task additions
    if (showAddTaskDialog) {
        AddTaskDialog(
            onDismiss = { showAddTaskDialog = false },
            onConfirm = { title, category, time ->
                viewModel.insertTask(
                    RoutineTask(
                        title = title,
                        category = category,
                        time = time,
                        isVoiceCreated = false,
                        aiSuggestedTips = when (category) {
                            "Morning" -> "Rise and shine! Set active early momentum today."
                            "Work" -> "Use focus hours and standard pause blocks."
                            "Evening" -> "Relax fully. Disable device screens."
                            "Health" -> "Consistency over intensity is the gold standard."
                            else -> "Stay on track!"
                        }
                    )
                )
                showAddTaskDialog = false
            }
        )
    }

    if (showVoiceSettingsDialog) {
        VoiceSettingsDialog(
            onDismiss = { showVoiceSettingsDialog = false },
            viewModel = viewModel
        )
    }
}

@Composable
fun NovaHeader(
    isProcessing: Boolean,
    onSettingsClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "NOVA",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "AI",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF818CF8),
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                // Animated pulse orb to indicate AI active/thinking state
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .graphicsLayer(alpha = if (isProcessing) pulseAlpha else 0.8f)
                        .background(
                            color = if (isProcessing) Color(0xFFC084FC) else Color(0xFF818CF8),
                            shape = CircleShape
                        )
                )
            }
            Text(
                text = "Voice Assistant & Routine Hub",
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White.copy(alpha = 0.7f)
            )
        }

        IconButton(
            onClick = onSettingsClick,
            modifier = Modifier
                .background(Color.White.copy(alpha = 0.12f), CircleShape)
                .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)), CircleShape)
                .size(40.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Nova Assistant parameters",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun AssistantView(
    chatMessages: List<ChatMessage>,
    isProcessing: Boolean,
    isListening: Boolean,
    soundLevel: Float,
    speechText: String,
    speechError: String?,
    onMicClicked: () -> Unit,
    onSendMessage: (String) -> Unit,
    onSuggestionClicked: (String) -> Unit,
    viewModel: NovaViewModel
) {
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var userPromptText by remember { mutableStateOf("") }

    // Scroll to the latest turn automatically
    LaunchedEffect(chatMessages.size, isProcessing, isListening) {
        if (chatMessages.isNotEmpty()) {
            listState.animateScrollToItem(chatMessages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Glowing Premium Activation Banner right in front (bilcul samne)
        NovaActivationBanner(viewModel = viewModel)

        // Chat dialogues column
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(chatMessages) { msg ->
                ChatBubble(message = msg)
            }

            if (isProcessing) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = Purple500,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            "Nova is computing...",
                            fontSize = 13.sp,
                            color = Slate600,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Active Listening Panel Overlay (glowing wave visualizer)
        AnimatedVisibility(
            visible = isListening,
            enter = expandVertically(expandFrom = Alignment.Bottom) + fadeIn(),
            exit = shrinkVertically(shrinkTowards = Alignment.Bottom) + fadeOut()
        ) {
            ListeningOverlayCard(
                speechText = speechText,
                soundLevel = soundLevel,
                errorText = speechError,
                onCancel = onMicClicked
            )
        }

        // Suggestions Carousel
        if (!isListening) {
            Text(
                "Voice Quick Actions",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF818CF8),
                modifier = Modifier.padding(start = 4.dp, bottom = 4.dp, top = 8.dp)
            )
            val actions = listOf(
                "Add work task Project Review at 3 PM",
                "Schedule Health jog at 6 AM",
                "Add morning read book at 9 AM",
                "Clear all completed tasks"
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                actions.forEach { act ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.15f)),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable { onSuggestionClicked(act) }
                    ) {
                        Text(
                            text = act,
                            fontSize = 11.sp,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Standard Keyboard Command input + Mic button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            TextField(
                value = userPromptText,
                onValueChange = { userPromptText = it },
                placeholder = {
                    Text(
                        "Ask Nova or type routine command...",
                        color = Slate600,
                        fontSize = 14.sp
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, MinimalBorder, RoundedCornerShape(24.dp))
                    .testTag("text_input_field"),
                colors = TextFieldDefaults.colors(
                    focusedTextColor = Slate900,
                    unfocusedTextColor = Slate900,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    disabledContainerColor = Color.White,
                    focusedIndicatorColor = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                maxLines = 2,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    if (userPromptText.isNotBlank()) {
                        onSendMessage(userPromptText)
                        userPromptText = ""
                    }
                }),
                trailingIcon = {
                    if (userPromptText.isNotBlank()) {
                        IconButton(
                            onClick = {
                                onSendMessage(userPromptText)
                                userPromptText = ""
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Send text prompt to Nova AI",
                                tint = Indigo600
                            )
                        }
                    }
                }
            )

            // Siri Pulse Orb button
            SiriOrb(
                isListening = isListening,
                soundLevel = soundLevel,
                onClick = onMicClicked
            )
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    val isNova = message.sender == Sender.NOVA
    val alignment = if (isNova) Alignment.Start else Alignment.End
    val containerBg = if (isNova) Color.White.copy(alpha = 0.88f) else Indigo600.copy(alpha = 0.9f)
    val borderStroke = if (isNova) BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)) else null
    val cornerShape = if (isNova) {
        RoundedCornerShape(topStart = 4.dp, topEnd = 20.dp, bottomStart = 20.dp, bottomEnd = 20.dp)
    } else {
        RoundedCornerShape(topStart = 20.dp, topEnd = 4.dp, bottomStart = 20.dp, bottomEnd = 20.dp)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalAlignment = alignment
    ) {
        Card(
            shape = cornerShape,
            border = borderStroke,
            colors = CardDefaults.cardColors(containerColor = containerBg),
            modifier = Modifier
                .widthIn(max = 280.dp)
                .shadow(elevation = 2.dp, shape = cornerShape, spotColor = Slate900.copy(alpha = 0.1f))
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 4.dp)
                ) {
                    Icon(
                        imageVector = if (isNova) Icons.Default.Star else Icons.Default.AccountCircle,
                        contentDescription = null,
                        tint = if (isNova) Indigo600 else Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isNova) "Nova Assistant" else "Me",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isNova) Indigo600 else Color.White.copy(alpha = 0.9f)
                    )
                }
                Text(
                    text = message.text,
                    fontSize = 14.sp,
                    color = if (isNova) Slate900 else Color.White,
                    lineHeight = 20.sp
                )
            }
        }
        Text(
            text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp)),
            fontSize = 9.sp,
            color = Color.White.copy(alpha = 0.5f),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Suppress("DEPRECATION")
@Composable
fun SiriOrb(
    isListening: Boolean,
    soundLevel: Float,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition()

    // Base breathing size animation
    val basePulse by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    // Rotating visual angle
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    val scale = if (isListening) {
        basePulse + (soundLevel * 0.45f)
    } else {
        basePulse
    }

    Box(
        modifier = Modifier
            .size(56.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 28.dp),
                onClick = onClick
            )
            .testTag("voice_orb_button"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .rotate(rotationAngle)
        ) {
            val center = size.center
            val radius = (size.minDimension / 2f) * scale

            // Ambient background magenta glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Purple500.copy(alpha = 0.5f), Color.Transparent),
                    center = center,
                    radius = radius * 1.3f
                ),
                radius = radius * 1.3f,
                center = center
            )

            // Radiant neon cyan wave
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Indigo600.copy(alpha = 0.6f), Color.Transparent),
                    center = center,
                    radius = radius * 1.1f
                ),
                radius = radius * 1.1f,
                center = center
            )

            // Energetic center core
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Indigo600,
                        Purple500.copy(alpha = 0.7f),
                        Pink500.copy(alpha = 0.9f)
                    ),
                    center = center,
                    radius = radius * 0.85f
                ),
                radius = radius * 0.85f,
                center = center
            )
        }

        // Microphone Icon Overlay
        Box(
            modifier = Modifier
                .size(34.dp)
                .background(Color.White, CircleShape)
                .shadow(elevation = 2.dp, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Voice listening sensor orb",
                tint = if (isListening) Purple500 else Indigo600,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun ListeningOverlayCard(
    speechText: String,
    soundLevel: Float,
    errorText: String?,
    onCancel: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .shadow(8.dp, RoundedCornerShape(24.dp), spotColor = Indigo600.copy(alpha = 0.2f)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Brush.linearGradient(listOf(Indigo600, Purple500))),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(Indigo600, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Nova Voice Sensor",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Indigo600,
                        letterSpacing = 0.5.sp
                    )
                }

                IconButton(
                    onClick = onCancel,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Abort listening",
                        tint = Slate600,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Pulse wave audio display simulator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(40.dp)
                    .padding(horizontal = 24.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val heights = listOf(0.3f, 0.6f, 0.9f, 0.5f, 0.8f, 0.4f, 0.7f, 0.3f, 0.6f)
                heights.forEach { baseHeight ->
                    val animatedHeight by animateFloatAsState(
                        targetValue = if (soundLevel > 0f) baseHeight * (soundLevel * 1.5f).coerceAtMost(1f) else 0.15f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioHighBouncy)
                    )
                    Box(
                        modifier = Modifier
                            .width(5.dp)
                            .fillMaxHeight(animatedHeight)
                            .background(
                                brush = Brush.verticalGradient(listOf(Indigo600, Purple500)),
                                shape = CircleShape
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (speechText.isBlank()) "Listening..." else speechText,
                fontSize = 15.sp,
                color = Slate900,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            if (errorText != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = ErrorRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = errorText,
                        fontSize = 11.sp,
                        color = ErrorRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun RoutinePlannerView(
    tasks: List<RoutineTask>,
    onToggleComplete: (RoutineTask) -> Unit,
    onDeleteTask: (RoutineTask) -> Unit,
    onClearCompleted: () -> Unit,
    onAddTaskClicked: () -> Unit
) {
    val totalTasks = tasks.size
    val completedCount = tasks.count { it.isCompleted }
    val progress = if (totalTasks > 0) completedCount.toFloat() / totalTasks else 0f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        // Upper stats card
        ProgressBanner(
            completedCount = completedCount,
            totalCount = totalTasks,
            progress = progress,
            onClearCompleted = onClearCompleted
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "My Daily Routine Tracker",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Slate900
            )

            // Quick '+' float equivalent inside the tab view
            Button(
                onClick = onAddTaskClicked,
                colors = ButtonDefaults.buttonColors(containerColor = Indigo600),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New Routine Entry",
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    "Add Routine",
                    fontSize = 11.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (tasks.isEmpty()) {
            EmptyRoutinesState(onAddTaskClicked = onAddTaskClicked)
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(tasks, key = { it.id }) { task ->
                    RoutineTaskItem(
                        task = task,
                        onToggle = { onToggleComplete(task) },
                        onDelete = { onDeleteTask(task) }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}

@Composable
fun ProgressBanner(
    completedCount: Int,
    totalCount: Int,
    progress: Float,
    onClearCompleted: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .shadow(2.dp, RoundedCornerShape(20.dp), spotColor = Slate900.copy(alpha = 0.05f)),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(20.dp),
        border = BorderStroke(1.dp, MinimalBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "Today's Completion Rate",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Indigo600,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (totalCount == 0) "No active routine tasks" else "$completedCount of $totalCount Completed",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Slate900
                )
                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = progress,
                    color = Indigo600,
                    trackColor = MinimalBg,
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(8.dp)
                        .clip(CircleShape)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Circle Progress percentage
                Box(
                    modifier = Modifier.size(54.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = progress,
                        color = Purple500,
                        trackColor = MinimalBg,
                        strokeWidth = 5.dp,
                        modifier = Modifier.fillMaxSize()
                    )
                    Text(
                        "${(progress * 100).toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Slate900
                    )
                }

                if (completedCount > 0) {
                    Text(
                        text = "Clear completed",
                        fontSize = 10.sp,
                        color = Pink500,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .clickable { onClearCompleted() }
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun RoutineTaskItem(
    task: RoutineTask,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    val categoryColor = when (task.category) {
        "Morning" -> Color(0xFFFFB74D) // Amber
        "Work" -> Indigo600
        "Evening" -> Color(0xFF9575CD) // Purple
        "Health" -> SuccessGreen
        else -> Slate600
    }

    val categoryIcon = when (task.category) {
        "Morning" -> Icons.Default.Star
        "Work" -> Icons.Default.List
        "Evening" -> Icons.Default.Star
        "Health" -> Icons.Default.Favorite
        else -> Icons.Default.DateRange
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(16.dp), spotColor = Slate900.copy(alpha = 0.05f))
            .clickable { isExpanded = !isExpanded },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(
            1.dp,
            if (task.isCompleted) SuccessGreen.copy(alpha = 0.3f) else MinimalBorder
        ),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Category icon badge
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(categoryColor.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = categoryIcon,
                            contentDescription = null,
                            tint = categoryColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = task.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (task.isCompleted) Slate400 else Slate900,
                            style = LocalTextStyle.current.copy(
                                textDecoration = if (task.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = task.category,
                                fontSize = 11.sp,
                                color = categoryColor,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(modifier = Modifier.size(4.dp).background(Slate400, CircleShape))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = task.time,
                                fontSize = 11.sp,
                                color = Slate600,
                                fontWeight = FontWeight.Medium
                            )

                            if (task.isVoiceCreated) {
                                Spacer(modifier = Modifier.width(8.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Purple500.copy(alpha = 0.1f)),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "Voice",
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Purple500,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onToggle,
                        modifier = Modifier.testTag("toggle_task_checkbox")
                    ) {
                        Icon(
                            imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.Favorite,
                            contentDescription = "Complete task",
                            tint = if (task.isCompleted) SuccessGreen else Slate400,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.testTag("delete_task_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete routine",
                            tint = ErrorRed.copy(alpha = 0.8f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            // Expanding Intelligent AI tips and actions
            AnimatedVisibility(visible = isExpanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .background(MinimalBg, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = Purple500,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Nova Smart Tip",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Purple500,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = task.aiSuggestedTips ?: "Nova is compiling optimization metrics for this routine schedule.",
                        fontSize = 12.sp,
                        color = Slate900,
                        lineHeight = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyRoutinesState(onAddTaskClicked: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .border(2.dp, Indigo600, CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.nova_ai_avatar),
                contentDescription = "Nova AI Logo avatar",
                modifier = Modifier.fillMaxSize(),
                contentScale = androidx.compose.ui.layout.ContentScale.Crop
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "Routine schedule is blank",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Slate900
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            "Speak to Nova to schedule today's routine tasks automatically, or click below to enter one manually.",
            fontSize = 12.sp,
            color = Slate600,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp)
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
            onClick = onAddTaskClicked,
            colors = ButtonDefaults.buttonColors(containerColor = Indigo600),
            shape = RoundedCornerShape(20.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Add,
                contentDescription = null,
                tint = Color.White
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                "Create First Task",
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTaskDialog(
    onDismiss: () -> Unit,
    onConfirm: (String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Morning") }
    var selectedHour by remember { mutableStateOf("08") }
    var selectedMinute by remember { mutableStateOf("00") }
    var amPm by remember { mutableStateOf("AM") }

    val categories = listOf("Morning", "Work", "Evening", "Health")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "New Smart Task",
                color = Slate900,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp
            )
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Task Title input
                TextField(
                    value = title,
                    onValueChange = { title = it },
                    placeholder = { Text("Task Description (e.g. Yoga Session)") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedTextColor = Slate900,
                        unfocusedTextColor = Slate900,
                        focusedContainerColor = MinimalBg,
                        unfocusedContainerColor = MinimalBg,
                        focusedIndicatorColor = Indigo600,
                        unfocusedIndicatorColor = Color.Transparent
                    )
                )

                // Category badges picker
                Text(
                    "Category",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Indigo600
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = cat == selectedCategory
                        val catBg = if (isSelected) Indigo600 else MinimalBg
                        val catText = if (isSelected) Color.White else Slate600
                        Card(
                            colors = CardDefaults.cardColors(containerColor = catBg),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedCategory = cat }
                        ) {
                            Text(
                                text = cat,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = catText,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            )
                        }
                    }
                }

                // Time picker layout
                Text(
                    "Schedule Time",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Indigo600
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Hour picker
                    TimePickerDropdown(
                        selected = selectedHour,
                        options = (1..12).map { String.format("%02d", it) },
                        onSelect = { selectedHour = it },
                        modifier = Modifier.weight(1f)
                    )
                    Text(":", color = Slate900, fontWeight = FontWeight.Bold)
                    // Minute picker
                    TimePickerDropdown(
                        selected = selectedMinute,
                        options = listOf("00", "15", "30", "45"),
                        onSelect = { selectedMinute = it },
                        modifier = Modifier.weight(1f)
                    )
                    // AM / PM
                    TimePickerDropdown(
                        selected = amPm,
                        options = listOf("AM", "PM"),
                        onSelect = { amPm = it },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(title, selectedCategory, "$selectedHour:$selectedMinute $amPm")
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text(
                    "Add",
                    color = if (title.isNotBlank()) Indigo600 else Slate400,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Slate600)
            }
        }
    )
}

@Composable
fun TimePickerDropdown(
    selected: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MinimalBg),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { expanded = true }
        ) {
            Text(
                text = selected,
                color = Slate900,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.background(Color.White)
        ) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = { Text(opt, color = Slate900, fontWeight = FontWeight.Bold) },
                    onClick = {
                        onSelect(opt)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun VoiceSettingsDialog(
    onDismiss: () -> Unit,
    viewModel: NovaViewModel
) {
    val selectedVoiceIndex by viewModel.selectedVoiceIndex.collectAsState()
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = Indigo600,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    "Nova Voice Settings",
                    color = Slate900,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp
                )
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Select a personalized voice (5 Female/Girl, 5 Male/Boy voices) for Nova's replies. Each profile provides distinct natural speech parameters.",
                    color = Slate600,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(viewModel.voiceProfiles) { index, profile ->
                            val isSelected = selectedVoiceIndex == index
                            val genderColor = if (profile.gender == "Girl") Pink500 else Indigo600
                            val genderBg = if (profile.gender == "Girl") Color(0xFFFDF2F8) else Indigo50
                            
                            Card(
                                onClick = {
                                    viewModel.selectVoice(index)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) Indigo600 else MinimalBorder,
                                        shape = RoundedCornerShape(16.dp)
                                    ),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) Indigo50.copy(alpha = 0.5f) else Color.White
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Gender Badge / Avatar
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(genderBg, shape = CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (profile.gender == "Girl") "🚺" else "🚹",
                                            fontSize = 18.sp
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(12.dp))
                                    
                                    // Voice Details
                                    Column(
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = profile.name,
                                                color = Slate900,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            
                                            // Gender Badge
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        color = genderColor.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = profile.gender,
                                                    color = genderColor,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }
                                        
                                        Spacer(modifier = Modifier.height(2.dp))
                                        
                                        Text(
                                            text = profile.description,
                                            color = Slate600,
                                            fontSize = 11.sp,
                                            lineHeight = 14.sp
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(8.dp))
                                    
                                    // Check or Play Preview Button
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Indigo600,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Preview Voice",
                                            tint = Slate400,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Indigo600),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Done", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun NovaActivationBanner(
    viewModel: NovaViewModel,
    modifier: Modifier = Modifier
) {
    val isActivated by viewModel.isActivated.collectAsState()
    val selectedVoiceIndex by viewModel.selectedVoiceIndex.collectAsState()
    val voiceProfile = viewModel.voiceProfiles.getOrNull(selectedVoiceIndex)
    
    var showVoiceChooser by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val requestPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        showVoiceChooser = true
    }

    val infiniteTransition = rememberInfiniteTransition()
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        )
    )

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActivated) Color(0xFF0F172A).copy(alpha = 0.85f) else Color(0xFF1E1B4B).copy(alpha = 0.9f)
        ),
        border = BorderStroke(
            width = 1.5.dp,
            color = if (isActivated) Color(0xFF10B981).copy(alpha = 0.6f) else Color(0xFF818CF8).copy(alpha = 0.8f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .shadow(
                elevation = if (isActivated) 4.dp else 12.dp,
                shape = RoundedCornerShape(20.dp),
                ambientColor = if (isActivated) Color(0xFF10B981) else Color(0xFF818CF8),
                spotColor = if (isActivated) Color(0xFF10B981) else Color(0xFF818CF8)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Status Glowing Orb
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        color = if (isActivated) Color(0xFF10B981).copy(alpha = 0.2f) else Color(0xFF818CF8).copy(alpha = 0.2f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .graphicsLayer {
                            if (!isActivated) {
                                alpha = pulseAlpha
                            }
                        }
                        .background(
                            color = if (isActivated) Color(0xFF10B981) else Color(0xFF818CF8),
                            shape = CircleShape
                        )
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = if (isActivated) "NOVA AI ACTIVE 🟢" else "ACTIVATE NOVA AI 🎙️",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = if (isActivated) "Voice Profile: ${voiceProfile?.name ?: "Male Signature"} (${voiceProfile?.gender ?: "Boy"})" else "Unlock personalized speech response core",
                    fontSize = 11.sp,
                    color = if (isActivated) Color.White.copy(alpha = 0.7f) else Color(0xFFC7D2FE)
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = {
                    val permissions = if (android.os.Build.VERSION.SDK_INT >= 33) {
                        arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        arrayOf(Manifest.permission.RECORD_AUDIO)
                    }
                    requestPermissionLauncher.launch(permissions)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActivated) Color.White.copy(alpha = 0.15f) else Color(0xFF818CF8)
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isActivated) "RE-ACTIVATE" else "ACTIVATE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White
                )
            }
        }
    }

    if (showVoiceChooser) {
        VoiceActivationDialog(
            onDismiss = { showVoiceChooser = false },
            onActivate = { voiceIndex ->
                viewModel.activateNova(voiceIndex)
                showVoiceChooser = false
            },
            viewModel = viewModel
        )
    }
}

@Composable
fun NovaActivationGateway(
    viewModel: NovaViewModel,
    modifier: Modifier = Modifier
) {
    var showVoiceChooser by remember { mutableStateOf(false) }
    val context = LocalContext.current

    // Permission request launcher
    val requestPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // No matter what they choose, we proceed to voice selection to ensure maximum compatibility/simulation
        showVoiceChooser = true
    }

    val infiniteTransition = rememberInfiniteTransition()
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    val rotateAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Large Premium Logo/Sphere Visual representation
        Box(
            modifier = Modifier
                .size(160.dp)
                .graphicsLayer {
                    scaleX = pulseScale
                    scaleY = pulseScale
                },
            contentAlignment = Alignment.Center
        ) {
            // Inner neon glow
            Box(
                modifier = Modifier
                    .size(140.dp)
                    .rotate(rotateAngle)
                    .background(
                        brush = Brush.sweepGradient(
                            colors = listOf(
                                Color(0xFF818CF8), // Indigo
                                Color(0xFFC084FC), // Purple
                                Color(0xFFF472B6), // Pink
                                Color(0xFF818CF8)
                            )
                        ),
                        shape = CircleShape
                    )
            )
            // Mask to create futuristic inner circle
            Box(
                modifier = Modifier
                    .size(134.dp)
                    .background(Color(0xFF0F172A), shape = CircleShape)
            )

            // Center icon/orb representing AI voice activation
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF818CF8).copy(alpha = 0.4f), Color.Transparent)
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow, // Play button icon inside sphere
                    contentDescription = "Holographic voice orb",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // App Title Section
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = "ACTIVATE ",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color.White,
                letterSpacing = 2.sp
            )
            Text(
                text = "NOVA AI",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = Color(0xFF818CF8),
                letterSpacing = 2.sp
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Initiate the interactive voice core to synthesize realistic voices, activate responsive speech commands, and automate routine reminders.",
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 14.sp,
            lineHeight = 20.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Key Value Card features list
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            ActivationFeatureRow(
                icon = "🎙️",
                title = "Smart Voice Commands",
                desc = "Natural speech queries using Android's offline & online Speech Recognizer core."
            )
            ActivationFeatureRow(
                icon = "🔊",
                title = "Realistic Speech Synthesis",
                desc = "Choose from 10 distinct masculine and feminine voice profiles tailored for high clarity."
            )
            ActivationFeatureRow(
                icon = "🔔",
                title = "Status & Routine Sync",
                desc = "Keep the assistant active in the status bar with persistent service notification."
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        // Big Activate Button
        Button(
            onClick = {
                val permissions = if (android.os.Build.VERSION.SDK_INT >= 33) {
                    arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    arrayOf(Manifest.permission.RECORD_AUDIO)
                }
                requestPermissionLauncher.launch(permissions)
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF818CF8)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .shadow(12.dp, RoundedCornerShape(16.dp), ambientColor = Color(0xFF818CF8)),
            contentPadding = PaddingValues(0.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Favorite, // Cool spark/heart icon
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "ACTIVATE CORE SYSTEMS",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showVoiceChooser) {
        VoiceActivationDialog(
            onDismiss = { showVoiceChooser = false },
            onActivate = { voiceIndex ->
                viewModel.activateNova(voiceIndex)
                showVoiceChooser = false
            },
            viewModel = viewModel
        )
    }
}

@Composable
fun ActivationFeatureRow(
    icon: String,
    title: String,
    desc: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.08f)
        ),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = icon,
                fontSize = 24.sp,
                modifier = Modifier.padding(end = 16.dp)
            )
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = title,
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = desc,
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
fun VoiceActivationDialog(
    onDismiss: () -> Unit,
    onActivate: (Int) -> Unit,
    viewModel: NovaViewModel
) {
    var selectedVoiceIndex by remember { mutableStateOf(0) }
    
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = Indigo600,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    "Choose Companion Voice",
                    color = Slate900,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp
                )
            }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    "Select a signature voice for Nova's replies. You can change this profile anytime in settings.",
                    color = Slate600,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(viewModel.voiceProfiles) { index, profile ->
                            val isSelected = selectedVoiceIndex == index
                            val genderColor = if (profile.gender == "Girl") Pink500 else Indigo600
                            val genderBg = if (profile.gender == "Girl") Color(0xFFFDF2F8) else Indigo50
                            
                            Card(
                                onClick = {
                                    selectedVoiceIndex = index
                                    viewModel.selectVoice(index) // Let them hear the voice preview immediately on click!
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(
                                        width = if (isSelected) 2.dp else 1.dp,
                                        color = if (isSelected) Indigo600 else MinimalBorder,
                                        shape = RoundedCornerShape(16.dp)
                                    ),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) Indigo50.copy(alpha = 0.5f) else Color.White
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Gender Badge
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .background(genderBg, shape = CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (profile.gender == "Girl") "🚺" else "🚹",
                                            fontSize = 16.sp
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(10.dp))
                                    
                                    // Voice Details
                                    Column(
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            Text(
                                                text = profile.name,
                                                color = Slate900,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            
                                            // Gender Badge
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        color = genderColor.copy(alpha = 0.15f),
                                                        shape = RoundedCornerShape(8.dp)
                                                    )
                                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = profile.gender,
                                                    color = genderColor,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.sp
                                                )
                                            }
                                        }
                                        
                                        Spacer(modifier = Modifier.height(2.dp))
                                        
                                        Text(
                                            text = profile.description,
                                            color = Slate600,
                                            fontSize = 11.sp,
                                            lineHeight = 14.sp
                                        )
                                    }
                                    
                                    Spacer(modifier = Modifier.width(6.dp))
                                    
                                    if (isSelected) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Selected",
                                            tint = Indigo600,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    } else {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = "Preview",
                                            tint = Slate400,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onActivate(selectedVoiceIndex) },
                colors = ButtonDefaults.buttonColors(containerColor = Indigo600),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Confirm & Activate", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Slate600, fontWeight = FontWeight.Bold)
            }
        }
    )
}
