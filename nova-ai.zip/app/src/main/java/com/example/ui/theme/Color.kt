package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Color Theme
val MinimalBg = Color(0xFFF3F4F9)
val MinimalSurface = Color(0xFFFFFFFF)
val MinimalCard = Color(0xF0FFFFFF) // translucent white/80
val MinimalBorder = Color(0xFFE2E8F0)

val Slate900 = Color(0xFF0F172A)
val Slate600 = Color(0xFF475569)
val Slate400 = Color(0xFF94A3B8)
val Indigo600 = Color(0xFF4F46E5)
val Indigo950 = Color(0xFF1E1B4B)
val Purple500 = Color(0xFFA855F7)
val Pink500 = Color(0xFFEC4899)
val Indigo50 = Color(0xFFEEF2FF)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFEF4444)

// Classic fallback
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)


