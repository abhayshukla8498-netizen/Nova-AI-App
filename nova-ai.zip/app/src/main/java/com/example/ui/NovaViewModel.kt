package com.example.ui

import android.app.Application
import android.app.ActivityManager
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import com.example.data.AppDatabase
import com.example.data.RoutineTask
import com.example.data.RoutineTaskRepository
import com.example.network.Content
import com.example.network.GeminiRequest
import com.example.network.Part
import com.example.network.RetrofitClient
import com.example.network.SystemInstruction
import com.example.network.GenerationConfig
import com.example.voice.VoiceCommandManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

import android.app.NotificationChannel
import android.app.NotificationManager
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.example.R

// Phone control & info imports
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.net.URLEncoder

data class VoiceProfile(
    val id: Int,
    val name: String,
    val gender: String, // "Girl" or "Boy"
    val locale: java.util.Locale,
    val pitch: Float,
    val rate: Float,
    val description: String
)

class NovaViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    val voiceProfiles = listOf(
        VoiceProfile(0, "Sophia (Futuristic Girl)", "Girl", java.util.Locale.US, 1.25f, 1.05f, "Elegant & high-fidelity US female voice"),
        VoiceProfile(1, "Oliver (Confident Boy)", "Boy", java.util.Locale.UK, 0.9f, 0.95f, "British accent confident male voice"),
        VoiceProfile(2, "Emily (Warm Girl)", "Girl", java.util.Locale.UK, 1.15f, 1.0f, "Gentle British warm female voice"),
        VoiceProfile(3, "Leo (Calm Boy)", "Boy", java.util.Locale.US, 0.85f, 1.0f, "Warm & deep American male voice"),
        VoiceProfile(4, "Chloe (Sweet Girl)", "Girl", java.util.Locale.CANADA, 1.3f, 1.1f, "Canadian sweet and cheerful female voice"),
        VoiceProfile(5, "Ethan (Clear Boy)", "Boy", java.util.Locale.US, 1.0f, 1.05f, "Active and clear American boy voice"),
        VoiceProfile(6, "Lily (Gentle Girl)", "Girl", java.util.Locale.US, 1.1f, 0.95f, "Soft and soothing American female voice"),
        VoiceProfile(7, "Mason (Deep Boy)", "Boy", java.util.Locale.UK, 0.78f, 0.98f, "Classic deep British male voice"),
        VoiceProfile(8, "Zoe (Active Girl)", "Girl", java.util.Locale.US, 1.35f, 1.15f, "Energetic and lively US girl voice"),
        VoiceProfile(9, "Lucas (Soft Boy)", "Boy", java.util.Locale.CANADA, 0.95f, 1.0f, "Gentle Canadian male voice")
    )

    private val _selectedVoiceIndex = MutableStateFlow(0)
    val selectedVoiceIndex: StateFlow<Int> = _selectedVoiceIndex.asStateFlow()

    private val _isActivated = MutableStateFlow(false)
    val isActivated: StateFlow<Boolean> = _isActivated.asStateFlow()

    private val repository: RoutineTaskRepository
    val allTasks: StateFlow<List<RoutineTask>>

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    init {
        val database = AppDatabase.getDatabase(application)
        repository = RoutineTaskRepository(database.routineTaskDao())
        allTasks = repository.allTasks.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        // Load voice preference and activation
        val prefs = application.getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
        _selectedVoiceIndex.value = prefs.getInt("selected_voice_index", 0)
        _isActivated.value = prefs.getBoolean("is_activated", false)

        // Initialize TTS
        tts = TextToSpeech(application, this)

        if (_isActivated.value) {
            postActiveNotification()
            // Start the interactive foreground service
            try {
                val serviceIntent = Intent(application, com.example.voice.NovaForegroundService::class.java).apply {
                    action = "com.example.voice.action.START"
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    application.startForegroundService(serviceIntent)
                } else {
                    application.startService(serviceIntent)
                }
            } catch (e: Exception) {
                Log.e("NovaViewModel", "Failed to start background service: ${e.message}")
            }
        }
    }

    fun activateNova(voiceIndex: Int) {
        if (voiceIndex in voiceProfiles.indices) {
            _selectedVoiceIndex.value = voiceIndex
            _isActivated.value = true
            
            val prefs = getApplication<Application>().getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
            prefs.edit()
                .putBoolean("is_activated", true)
                .putInt("selected_voice_index", voiceIndex)
                .apply()
            
            postActiveNotification()
            
            // Start the interactive foreground service
            try {
                val serviceIntent = Intent(getApplication(), com.example.voice.NovaForegroundService::class.java).apply {
                    action = "com.example.voice.action.START"
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    getApplication<Application>().startForegroundService(serviceIntent)
                } else {
                    getApplication<Application>().startService(serviceIntent)
                }
            } catch (e: Exception) {
                Log.e("NovaViewModel", "Failed to start background service on activation: ${e.message}")
            }
            
            // Speak confirmation
            val voiceName = voiceProfiles[voiceIndex].name
            speak("Hello Sir. I am Nova AI. My systems are fully active. How can I help you today?")
        }
    }

    fun postActiveNotification() {
        val context = getApplication<Application>()
        val channelId = "nova_ai_activation"
        val channelName = "Nova AI System Status"
        val notificationId = 10101
        
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Shows that Nova AI is activated and running properly."
                setShowBadge(true)
            }
            notificationManager.createNotificationChannel(channel)
        }
        
        val profile = voiceProfiles[_selectedVoiceIndex.value]
        
        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(com.example.R.drawable.ic_launcher_foreground)
            .setContentTitle("NOVA AI ACTIVE")
            .setContentText("Voice core online with ${profile.name}")
            .setSubText("Nova Assistant")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setOngoing(true)
            .setAutoCancel(false)
            .setColor(0xFF818CF8.toInt())
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            
        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (e: Exception) {
            Log.e("NovaViewModel", "Failed to show notification: ${e.message}")
        }
    }

    fun selectVoice(index: Int) {
        if (index in voiceProfiles.indices) {
            _selectedVoiceIndex.value = index
            val prefs = getApplication<Application>().getSharedPreferences("nova_settings", Context.MODE_PRIVATE)
            prefs.edit().putInt("selected_voice_index", index).apply()
            
            // Also speak a short preview of the selected voice so the user hears it immediately!
            val voiceName = voiceProfiles[index].name
            speak("Hello Sir. This is my new voice. I am $voiceName. How do I sound?")
            
            // Update active notification text with the new voice name
            if (_isActivated.value) {
                postActiveNotification()
            }
        }
    }

    val voiceManager = VoiceCommandManager(application)

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage(
            sender = Sender.NOVA,
            text = "Hello! I am NOVA, your intelligent voice AI assistant. Speak or type to manage your daily routines. Try saying: 'Add a Morning task to meditate at 7 AM'!"
        )
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing

    private val _activeTab = MutableStateFlow(0) // 0 for Voice Assistant, 1 for Routine Planner
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    fun setActiveTab(index: Int) {
        _activeTab.value = index
    }

    // Task Actions
    fun insertTask(task: RoutineTask) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertTask(task)
        }
    }

    fun updateTask(task: RoutineTask) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateTask(task)
        }
    }

    fun deleteTask(task: RoutineTask) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteTask(task)
        }
    }

    fun clearCompleted() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearCompletedTasks()
        }
    }

    fun handleUserMessage(messageText: String) {
        if (messageText.isBlank()) return

        // Add user message to chat
        val userMsg = ChatMessage(sender = Sender.USER, text = messageText)
        _chatMessages.value = _chatMessages.value + userMsg

        val lowerText = messageText.lowercase().trim()
        if (!lowerText.contains("nova") && !lowerText.contains("nowa") && !lowerText.contains("noba")) {
            addNovaMessage("Sir, please say NOVA first before the task.")
            return
        }

        _isProcessing.value = true

        viewModelScope.launch {
            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                // Return local simulation parser if API key is placeholders
                handleLocalSimulation(messageText)
                _isProcessing.value = false
                return@launch
            }

            // Build system instructions for Siri-like features & smart routing
            val systemInstructionText = """
                You are Nova AI, an ultra-smart, friendly voice assistant like Siri for Android.
                You help users with general queries, daily routines, and device controls.
                
                The user can manage their routines through tasks with:
                - title, category ("Morning", "Work", "Evening", "Health"), and time (e.g., "08:30 AM").
                If the user wants to add, create, toggle, or clear tasks, start with:
                [TASK_ACTION]{"action":"CREATE","title":"...","category":"...","time":"...","aiSuggestedTips":"..."}[/TASK_ACTION]
                
                If the user wants to perform physical or settings commands on their device:
                1. OPENING APPS: "open youtube", "open settings", "open whatsapp", "open facebook", "open instagram", "open chrome", "open camera", "open gallery", "open calculator", "open file manager".
                   Output: [PHONE_ACTION]{"action":"OPEN_APP","target":"youtube"}[/PHONE_ACTION] (or correct app target name).
                   IMPORTANT: If the target is "youtube", your voice reply MUST be exactly: "Ok Sir, open kar raha hu."
                2. CALLING MUMMY: "call mummy", "mummy ko call karo", "call mom".
                   Output: [PHONE_ACTION]{"action":"CALL_MUMMY"}[/PHONE_ACTION]
                   IMPORTANT: Your voice reply MUST be exactly: "Ok Sir, mummy ko call kar rahi hu."
                3. WIFI: "turn on wifi", "wifi settings", "open wifi", "wifi".
                   Output: [PHONE_ACTION]{"action":"WIFI"}[/PHONE_ACTION]
                   IMPORTANT: Your voice reply MUST be exactly: "Ok Sir, wifi on kar raha hu."
                4. FLASHLIGHT: "flashlight on", "turn on light", "torch off".
                   Output: [PHONE_ACTION]{"action":"FLASHLIGHT","state":"on"}[/PHONE_ACTION] or "off"
                5. VOLUME: "volume up", "decrease volume", "mute".
                   Output: [PHONE_ACTION]{"action":"VOLUME","state":"increase"}[/PHONE_ACTION], "decrease", "mute", "unmute"
                6. SETTINGS PANELS: "bluetooth settings", "mobile data settings", "airplane mode settings", "hotspot settings".
                   Output: [PHONE_ACTION]{"action":"BLUETOOTH"}[/PHONE_ACTION], etc.
                7. SEARCH INTERNET: "google search for query", "search youtube for query", "maps query".
                   Output: [PHONE_ACTION]{"action":"SEARCH","target":"google","query":"..."}[/PHONE_ACTION], target can be "youtube", "maps", "google".
                8. DEVICE INFO: "battery level", "are you charging", "ram usage", "storage info", "device name", "android version".
                   Output: [PHONE_ACTION]{"action":"BATTERY_INFO"}[/PHONE_ACTION], [PHONE_ACTION]{"action":"RAM_INFO"}[/PHONE_ACTION], [PHONE_ACTION]{"action":"STORAGE_INFO"}[/PHONE_ACTION], [PHONE_ACTION]{"action":"DEVICE_INFO"}[/PHONE_ACTION]
                9. ALARM/TIMER: "set alarm", "set timer".
                   Output: [PHONE_ACTION]{"action":"PRODUCTIVITY","type":"alarm"}[/PHONE_ACTION] or "timer".
                
                RESPONSE STYLE:
                Always follow the rule: Listen -> Understand -> Reply -> Execute.
                CRITICAL RULE: Every single reply you give to any user command or task MUST start with the word "Sir" or "Ok Sir" or "Sure Sir". This is COMPULSORY. Never reply without addressing the user as Sir at the absolute beginning of your response.
                Your conversational voice replies should be very polite, friendly, short (maximum 2 sentences), natural.
                For YouTube, calling Mummy, or Wifi, prioritize the specified Hindi-mix replies above exactly.
                
                Current Local Time: ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}
            """.trimIndent()

            // Map recent messages to retrofitted Gemini format
            val recentMessages = _chatMessages.value.takeLast(6)
            val contents = recentMessages.filter { !it.isSystemNotification }.map { msg ->
                Content(parts = listOf(Part(text = msg.text)))
            }

            val request = GeminiRequest(
                contents = contents,
                systemInstruction = SystemInstruction(parts = listOf(Part(text = systemInstructionText))),
                generationConfig = GenerationConfig(temperature = 0.7f)
            )

            try {
                val response = withContext(Dispatchers.IO) {
                    RetrofitClient.service.generateContent(apiKey, request)
                }
                val rawResponse = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (rawResponse != null) {
                    processNovaResponse(rawResponse)
                } else {
                    addNovaMessage("I encountered a small hiccup receiving a response. Speak again, please!")
                }
            } catch (e: Exception) {
                // Fallback to local offline parser if API fails or key is invalid
                handleLocalSimulation(messageText, errorDetails = e.message)
            } finally {
                _isProcessing.value = false
            }
        }
    }

    private fun handleLocalSimulation(text: String, errorDetails: String? = null) {
        val lowerText = text.lowercase().trim()
        val routineCategory = when {
            lowerText.contains("morning") || lowerText.contains("wake") || lowerText.contains("breakfast") -> "Morning"
            lowerText.contains("work") || lowerText.contains("office") || lowerText.contains("study") || lowerText.contains("project") -> "Work"
            lowerText.contains("evening") || lowerText.contains("night") || lowerText.contains("dinner") || lowerText.contains("sleep") -> "Evening"
            lowerText.contains("health") || lowerText.contains("exercise") || lowerText.contains("gym") || lowerText.contains("water") || lowerText.contains("run") || lowerText.contains("walk") -> "Health"
            else -> "Work"
        }

        // Match time pattern
        var extractedTime = "Anytime"
        val timeRegex = """\b(1[0-2]|0?[1-9])(?::([0-5][0-9]))?\s*(am|pm|AM|PM)\b""".toRegex()
        val match = timeRegex.find(text)
        if (match != null) {
            extractedTime = match.value.uppercase()
        }

        val aiTips = when (routineCategory) {
            "Morning" -> "Starting early builds a strong morning momentum!"
            "Work" -> "Take a 5-minute break every 25 minutes (Pomodoro technique)."
            "Evening" -> "Wind down screen time 1 hour before sleep."
            "Health" -> "Hydrate properly during this activity!"
            else -> "Stay consistent and track your goals!"
        }

        viewModelScope.launch {
            // Check for phone actions offline
            when {
                lowerText.contains("open youtube") || (lowerText.contains("youtube") && lowerText.contains("open")) -> {
                    addNovaMessage("Ok Sir, open kar raha hu.")
                    openApp("youtube")
                }
                lowerText.contains("call mummy") || (lowerText.contains("mummy") && lowerText.contains("call")) -> {
                    addNovaMessage("Ok Sir, mummy ko call kar rahi hu.")
                    val dialIntent = Intent(Intent.ACTION_DIAL, android.net.Uri.parse("tel:9876543210")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        getApplication<Application>().startActivity(dialIntent)
                    } catch (e: Exception) {
                        Toast.makeText(getApplication(), "Dialer unavailable", Toast.LENGTH_SHORT).show()
                    }
                }
                lowerText.startsWith("open ") -> {
                    val target = lowerText.removePrefix("open ").trim()
                    val replyText = "Sure Sir, opening $target."
                    addNovaMessage(replyText)
                    openApp(target)
                }
                lowerText.contains("flashlight on") || lowerText.contains("torch on") || lowerText.contains("turn on light") -> {
                    addNovaMessage("Sure Sir, turning the flashlight ON.")
                    toggleFlashlight(true)
                }
                lowerText.contains("flashlight off") || lowerText.contains("torch off") || lowerText.contains("turn off light") -> {
                    addNovaMessage("Sure Sir, turning the flashlight OFF.")
                    toggleFlashlight(false)
                }
                lowerText.contains("volume up") || lowerText.contains("increase volume") -> {
                    addNovaMessage("Sure Sir, volume increased.")
                    controlVolume("increase")
                }
                lowerText.contains("volume down") || lowerText.contains("decrease volume") -> {
                    addNovaMessage("Sure Sir, volume decreased.")
                    controlVolume("decrease")
                }
                lowerText.contains("mute") -> {
                    addNovaMessage("Sure Sir, device is now muted.")
                    controlVolume("mute")
                }
                lowerText.contains("unmute") -> {
                    addNovaMessage("Sure Sir, device is now unmuted.")
                    controlVolume("unmute")
                }
                lowerText.contains("wifi") || lowerText.contains("wi-fi") -> {
                    addNovaMessage("Ok Sir, wifi on kar raha hu.")
                    openSettings("wifi")
                }
                lowerText.contains("bluetooth settings") || lowerText.contains("open bluetooth") || lowerText.contains("bluetooth") -> {
                    addNovaMessage("Sure Sir, opening Bluetooth settings.")
                    openSettings("bluetooth")
                }
                lowerText.contains("mobile data") || lowerText.contains("data settings") -> {
                    addNovaMessage("Opening Mobile Data Settings Sir.")
                    openSettings("data")
                }
                lowerText.contains("airplane mode") || lowerText.contains("airplane settings") -> {
                    addNovaMessage("Sure Sir, opening Airplane Mode settings.")
                    openSettings("airplane")
                }
                lowerText.contains("hotspot") || lowerText.contains("tethering") -> {
                    addNovaMessage("Sure Sir, opening Hotspot settings.")
                    openSettings("hotspot")
                }
                lowerText.contains("battery") -> {
                    val pct = getBatteryPercentage()
                    val isCharging = isPhoneCharging()
                    val chargingText = if (isCharging) "and currently charging" else "and not charging"
                    addNovaMessage("Sir, your battery level is $pct percent, $chargingText.")
                }
                lowerText.contains("ram") || lowerText.contains("memory") -> {
                    addNovaMessage("Sir, RAM memory usage details: ${getRamUsage()}.")
                }
                lowerText.contains("storage") || lowerText.contains("disk") -> {
                    addNovaMessage("Sir, your device storage details: ${getStorageUsage()}.")
                }
                lowerText.contains("device name") || lowerText.contains("phone model") -> {
                    addNovaMessage("Sir, you are using the ${Build.MODEL} device.")
                }
                lowerText.contains("android version") || lowerText.contains("os version") -> {
                    addNovaMessage("Sir, this device runs on Android Version ${Build.VERSION.RELEASE}.")
                }
                lowerText.contains("google search") || lowerText.contains("search for") -> {
                    val query = lowerText.replace("google search", "").replace("search for", "").trim()
                    addNovaMessage("Sir, performing Google search for: $query.")
                    performSearch("google", query)
                }
                lowerText.contains("youtube search") || lowerText.contains("search youtube for") -> {
                    val query = lowerText.replace("youtube search", "").replace("search youtube for", "").trim()
                    addNovaMessage("Sir, searching YouTube for: $query.")
                    performSearch("youtube", query)
                }
                lowerText.contains("maps search") || lowerText.contains("search maps for") || lowerText.startsWith("maps ") -> {
                    val query = lowerText.replace("maps search", "").replace("search maps for", "").replace("maps", "").trim()
                    addNovaMessage("Sir, opening Google Maps to locate: $query.")
                    performSearch("maps", query)
                }
                lowerText.contains("set alarm") || lowerText.contains("alarm at") -> {
                    addNovaMessage("Sure Sir, opening the alarm configuration.")
                    handleProductivity("alarm", text)
                }
                lowerText.contains("set timer") || lowerText.contains("timer for") -> {
                    addNovaMessage("Sure Sir, opening the timer configuration.")
                    handleProductivity("timer", text)
                }
                lowerText.contains("add") || lowerText.contains("create") || lowerText.contains("schedule") || lowerText.contains("task") || lowerText.contains("routine") -> {
                    var title = text.replace("add", "", ignoreCase = true)
                        .replace("create", "", ignoreCase = true)
                        .replace("schedule", "", ignoreCase = true)
                        .replace("task", "", ignoreCase = true)
                        .replace("routine", "", ignoreCase = true)
                        .replace("morning", "", ignoreCase = true)
                        .replace("evening", "", ignoreCase = true)
                        .replace("health", "", ignoreCase = true)
                        .replace("work", "", ignoreCase = true)
                        .replace("at $extractedTime", "", ignoreCase = true)
                        .trim()

                    if (title.isEmpty()) {
                        title = "New Daily Activity"
                    }

                    title = title.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString() }

                    val task = RoutineTask(
                        title = title,
                        category = routineCategory,
                        time = extractedTime,
                        isVoiceCreated = true,
                        aiSuggestedTips = aiTips
                    )
                    repository.insertTask(task)

                    val replyText = "Sure Sir, I have scheduled '$title' for your $routineCategory routine at $extractedTime."
                    addNovaMessage(replyText)
                }
                lowerText.contains("clear") && lowerText.contains("complete") -> {
                    repository.clearCompletedTasks()
                    addNovaMessage("Ok Sir, I have cleared all completed tasks for you.")
                }
                else -> {
                    val simulatedReply = when {
                        lowerText.contains("hello") || lowerText.contains("hi") || lowerText.contains("hey") ->
                            "Sir, hello! How can NOVA help you today?"
                        lowerText.contains("who are you") || lowerText.contains("about") ->
                            "Sir, I am NOVA, your intelligent voice AI assistant designed to optimize your daily routine and execute phone commands."
                        lowerText.contains("how are you") ->
                            "Sir, my virtual circuits are humming with energy! I'm ready to assist you."
                        lowerText.contains("date") || lowerText.contains("today") ->
                            "Sir, today is " + SimpleDateFormat("EEEE, MMMM dd, yyyy", Locale.getDefault()).format(Date())
                        lowerText.contains("time") ->
                            "Sir, the current time is " + SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
                        else ->
                            "Sir, I heard: '$text'. I can help you schedule your day, open apps, perform searches, or toggle settings. Try saying: 'NOVA open YouTube' or 'NOVA turn on wifi'."
                    }
                    addNovaMessage(simulatedReply)
                }
            }
        }
    }

    private fun processNovaResponse(rawResponse: String) {
        var cleanResponse = rawResponse
        var taskJsonBlock: String? = null
        var phoneJsonBlock: String? = null

        try {
            val taskStart = "[TASK_ACTION]"
            val taskEnd = "[/TASK_ACTION]"
            if (rawResponse.contains(taskStart) && rawResponse.contains(taskEnd)) {
                val startIndex = rawResponse.indexOf(taskStart)
                val endIndex = rawResponse.indexOf(taskEnd)
                taskJsonBlock = rawResponse.substring(startIndex + taskStart.length, endIndex).trim()
                cleanResponse = rawResponse.substring(0, startIndex) + rawResponse.substring(endIndex + taskEnd.length)
                cleanResponse = cleanResponse.trim()
            }
        } catch (e: Exception) {
            Log.e("NovaViewModel", "Error parsing task tags: ${e.message}")
        }

        try {
            val phoneStart = "[PHONE_ACTION]"
            val phoneEnd = "[/PHONE_ACTION]"
            if (cleanResponse.contains(phoneStart) && cleanResponse.contains(phoneEnd)) {
                val startIndex = cleanResponse.indexOf(phoneStart)
                val endIndex = cleanResponse.indexOf(phoneEnd)
                phoneJsonBlock = cleanResponse.substring(startIndex + phoneStart.length, endIndex).trim()
                cleanResponse = cleanResponse.substring(0, startIndex) + cleanResponse.substring(endIndex + phoneEnd.length)
                cleanResponse = cleanResponse.trim()
            }
        } catch (e: Exception) {
            Log.e("NovaViewModel", "Error parsing phone tags: ${e.message}")
        }

        if (cleanResponse.isNotEmpty()) {
            addNovaMessage(cleanResponse)
        }

        if (taskJsonBlock != null) {
            try {
                val json = JSONObject(taskJsonBlock)
                val action = json.optString("action")
                val title = json.optString("title", "New Routine")
                val category = json.optString("category", "Work")
                val time = json.optString("time", "Anytime")
                val aiSuggestedTips = json.optString("aiSuggestedTips", "Stay consistent!")

                viewModelScope.launch(Dispatchers.IO) {
                    when (action) {
                        "CREATE" -> {
                            val task = RoutineTask(
                                title = title,
                                category = category,
                                time = time,
                                isVoiceCreated = true,
                                aiSuggestedTips = aiSuggestedTips
                            )
                            repository.insertTask(task)
                        }
                        "CLEAR_COMPLETED" -> {
                            repository.clearCompletedTasks()
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("NovaViewModel", "Error executing task action: ${e.message}")
            }
        }

        if (phoneJsonBlock != null) {
            executePhoneAction(phoneJsonBlock)
        }
    }

    private fun executePhoneAction(actionJson: String) {
        try {
            val json = JSONObject(actionJson)
            val action = json.optString("action")
            val target = json.optString("target")
            val state = json.optString("state")
            val query = json.optString("query")
            val type = json.optString("type")

            when (action) {
                "OPEN_APP" -> openApp(target)
                "CALL_MUMMY" -> {
                    val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:9876543210")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        getApplication<Application>().startActivity(dialIntent)
                    } catch (e: Exception) {
                        Toast.makeText(getApplication(), "Dialer unavailable", Toast.LENGTH_SHORT).show()
                    }
                }
                "FLASHLIGHT" -> toggleFlashlight(state.equals("on", ignoreCase = true))
                "VOLUME" -> controlVolume(state)
                "WIFI", "BLUETOOTH", "DATA", "AIRPLANE", "HOTSPOT", "BRIGHTNESS" -> openSettings(action.lowercase())
                "SEARCH" -> performSearch(target, query)
                "PRODUCTIVITY" -> handleProductivity(type, query)
                "BATTERY_INFO" -> {
                    val pct = getBatteryPercentage()
                    val isCharging = isPhoneCharging()
                    val chargingText = if (isCharging) "and currently charging" else "and not charging"
                    Toast.makeText(getApplication(), "Battery: $pct% ($chargingText)", Toast.LENGTH_LONG).show()
                }
                "RAM_INFO" -> {
                    Toast.makeText(getApplication(), "RAM: ${getRamUsage()}", Toast.LENGTH_LONG).show()
                }
                "STORAGE_INFO" -> {
                    Toast.makeText(getApplication(), "Storage: ${getStorageUsage()}", Toast.LENGTH_LONG).show()
                }
                "DEVICE_INFO" -> {
                    Toast.makeText(getApplication(), "Device: ${Build.MODEL}, Android: ${Build.VERSION.RELEASE}", Toast.LENGTH_LONG).show()
                }
            }
        } catch (e: Exception) {
            Log.e("NovaViewModel", "Error executing phone action JSON: ${e.message}")
        }
    }

    private fun openApp(target: String) {
        val context = getApplication<Application>()
        val packageName = when (target.lowercase()) {
            "youtube" -> "com.google.android.youtube"
            "whatsapp" -> "com.whatsapp"
            "facebook" -> "com.facebook.katana"
            "instagram" -> "com.instagram.android"
            "chrome" -> "com.android.chrome"
            "settings" -> "com.android.settings"
            "calculator", "calc" -> "com.android.calculator2"
            "file manager", "files" -> "com.android.documentsui"
            "camera" -> {
                try {
                    val cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(cameraIntent)
                    return
                } catch (e: Exception) {
                    "com.android.camera"
                }
            }
            "gallery", "photos" -> {
                try {
                    val galleryIntent = Intent(Intent.ACTION_VIEW).apply {
                        type = "image/*"
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(galleryIntent)
                    return
                } catch (e: Exception) {
                    "com.android.gallery3d"
                }
            }
            else -> null
        }

        if (packageName != null) {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                val url = when (target.lowercase()) {
                    "youtube" -> "https://www.youtube.com"
                    "whatsapp" -> "https://web.whatsapp.com"
                    "facebook" -> "https://www.facebook.com"
                    "instagram" -> "https://www.instagram.com"
                    "chrome" -> "https://www.google.com"
                    else -> null
                }
                if (url != null) {
                    val browserIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(browserIntent)
                } else {
                    Toast.makeText(context, "App '$target' not installed. Running high-fidelity simulation.", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(context, "Opening simulated launcher for '$target'.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun toggleFlashlight(on: Boolean) {
        val context = getApplication<Application>()
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.getOrNull(0)
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, on)
                Toast.makeText(context, "Flashlight turned ${if (on) "ON" else "OFF"}", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e("NovaViewModel", "Flashlight toggle error: ${e.message}")
            Toast.makeText(context, "Flashlight turned ${if (on) "ON" else "OFF"} (Hardware Simulated)", Toast.LENGTH_SHORT).show()
        }
    }

    private fun controlVolume(state: String) {
        val context = getApplication<Application>()
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            when (state.lowercase()) {
                "increase", "up" -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    Toast.makeText(context, "Volume Increased", Toast.LENGTH_SHORT).show()
                }
                "decrease", "down" -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    Toast.makeText(context, "Volume Decreased", Toast.LENGTH_SHORT).show()
                }
                "mute" -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    Toast.makeText(context, "Volume Muted", Toast.LENGTH_SHORT).show()
                }
                "unmute" -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, AudioManager.FLAG_SHOW_UI)
                    Toast.makeText(context, "Volume Unmuted", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Log.e("NovaViewModel", "Volume control error: ${e.message}")
        }
    }

    private fun openSettings(type: String) {
        val context = getApplication<Application>()
        val action = when (type.lowercase()) {
            "wifi" -> android.provider.Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
            "data" -> android.provider.Settings.ACTION_DATA_ROAMING_SETTINGS
            "airplane" -> android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS
            "hotspot", "wireless" -> android.provider.Settings.ACTION_WIRELESS_SETTINGS
            "brightness", "display" -> android.provider.Settings.ACTION_DISPLAY_SETTINGS
            else -> android.provider.Settings.ACTION_SETTINGS
        }
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            try {
                val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (ex: Exception) {
                Toast.makeText(context, "Unable to open system settings panel.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun performSearch(engine: String, query: String) {
        val context = getApplication<Application>()
        if (query.isBlank()) return
        try {
            val url = when (engine.lowercase()) {
                "youtube" -> "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
                "maps", "map" -> "https://maps.google.com/?q=" + URLEncoder.encode(query, "UTF-8")
                else -> "https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8")
            }
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Search failed: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleProductivity(type: String, query: String) {
        val context = getApplication<Application>()
        try {
            when (type.lowercase()) {
                "alarm" -> {
                    val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Nova AI Alarm")
                    }
                    context.startActivity(intent)
                }
                "timer" -> {
                    val intent = Intent(android.provider.AlarmClock.ACTION_SET_TIMER).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        putExtra(android.provider.AlarmClock.EXTRA_LENGTH, 60)
                        putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Nova AI Timer")
                    }
                    context.startActivity(intent)
                }
                else -> {
                    Toast.makeText(context, "Opening productivity module for $type: $query", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "No system clock/alarm handler found: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun getBatteryPercentage(): Int {
        val batteryManager = getApplication<Application>().getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        return batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun isPhoneCharging(): Boolean {
        val intent = getApplication<Application>().registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
    }

    private fun getRamUsage(): String {
        val actManager = getApplication<Application>().getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        actManager.getMemoryInfo(memInfo)
        val totalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
        val availGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
        val usedGb = totalGb - availGb
        return String.format("%.1f GB used of %.1f GB", usedGb, totalGb)
    }

    private fun getStorageUsage(): String {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val blockSize = stat.blockSizeLong
        val totalBlocks = stat.blockCountLong
        val availableBlocks = stat.availableBlocksLong
        val totalSpace = (totalBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0)
        val availableSpace = (availableBlocks * blockSize) / (1024.0 * 1024.0 * 1024.0)
        val usedSpace = totalSpace - availableSpace
        return String.format("%.1f GB used of %.1f GB", usedSpace, totalSpace)
    }

    private fun adjustGenderPhrases(text: String, gender: String): String {
        var result = text
        if (gender == "Girl") {
            result = result.replace("raha hu", "rahi hu")
            result = result.replace("raha hoon", "rahi hoon")
            result = result.replace("raha", "rahi")
            result = result.replace("karta hu", "karti hu")
            result = result.replace("karta hoon", "karti hoon")
            result = result.replace("karta", "karti")
            result = result.replace("karunga", "karungi")
            result = result.replace("bataunga", "bataungi")
            result = result.replace("kar raha", "kar rahi")
            result = result.replace("kar raha hu", "kar rahi hu")
            result = result.replace("kar raha hoon", "kar rahi hoon")
            result = result.replace("karne ja raha", "karne ja rahi")
            result = result.replace("karta", "karti")
            result = result.replace("karta hu", "karti hu")
        } else {
            result = result.replace("rahi hu", "raha hu")
            result = result.replace("rahi hoon", "raha hoon")
            result = result.replace("rahi", "raha")
            result = result.replace("karti hu", "karta hu")
            result = result.replace("karti hoon", "karta hoon")
            result = result.replace("karti", "karta")
            result = result.replace("karungi", "karunga")
            result = result.replace("bataungi", "bataunga")
            result = result.replace("kar rahi", "kar raha")
            result = result.replace("kar rahi hu", "kar raha hu")
            result = result.replace("kar rahi hoon", "kar raha hoon")
            result = result.replace("karne ja rahi", "karne ja raha")
            result = result.replace("karti", "karta")
            result = result.replace("karti hu", "karta hu")
        }
        return result
    }

    private fun addNovaMessage(text: String) {
        val voiceIndex = _selectedVoiceIndex.value
        val profile = voiceProfiles.getOrNull(voiceIndex)
        val gender = profile?.gender ?: "Girl"
        val adjustedText = adjustGenderPhrases(text, gender)

        val novaMsg = ChatMessage(sender = Sender.NOVA, text = adjustedText)
        _chatMessages.value = _chatMessages.value + novaMsg
        speak(adjustedText)
    }

    private fun speak(text: String) {
        if (isTtsInitialized) {
            val cleanText = text
                .replace(Regex("\\[TASK_ACTION\\].*?\\[/TASK_ACTION\\]", RegexOption.DOT_MATCHES_ALL), "")
                .replace(Regex("\\[PHONE_ACTION\\].*?\\[/PHONE_ACTION\\]", RegexOption.DOT_MATCHES_ALL), "")
                .trim()
            if (cleanText.isNotEmpty()) {
                val profile = voiceProfiles[_selectedVoiceIndex.value]
                
                // Set custom parameters
                tts?.setPitch(profile.pitch)
                tts?.setSpeechRate(profile.rate)
                tts?.language = profile.locale
                
                // Intelligently scan and match available system voices for highest realism
                val systemVoices = tts?.voices
                if (systemVoices != null && systemVoices.isNotEmpty()) {
                    val targetGenderLower = profile.gender.lowercase()
                    val targetLocale = profile.locale
                    
                    val matchedVoice = systemVoices.filter { voice ->
                        voice.locale.language.equals(targetLocale.language, ignoreCase = true) &&
                        (targetLocale.country.isEmpty() || voice.locale.country.equals(targetLocale.country, ignoreCase = true))
                    }.find { voice ->
                        val voiceNameLower = voice.name.lowercase()
                        if (targetGenderLower == "girl") {
                            voiceNameLower.contains("female") || voiceNameLower.contains("fem") || 
                            voiceNameLower.contains("-f-") || voiceNameLower.contains("_f_") || 
                            voiceNameLower.contains("girl") || voiceNameLower.contains("soft")
                        } else {
                            voiceNameLower.contains("male") || voiceNameLower.contains("masc") || 
                            voiceNameLower.contains("-m-") || voiceNameLower.contains("_m_") || 
                            voiceNameLower.contains("boy") || voiceNameLower.contains("guy") || voiceNameLower.contains("deep")
                        }
                    } ?: systemVoices.find { voice ->
                        voice.locale.language.equals(targetLocale.language, ignoreCase = true) &&
                        (targetLocale.country.isEmpty() || voice.locale.country.equals(targetLocale.country, ignoreCase = true))
                    }
                    
                    if (matchedVoice != null) {
                        tts?.voice = matchedVoice
                    }
                }
                
                tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, null)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsInitialized = true
            }
        }
    }

    fun startListening() {
        voiceManager.startListening { voiceText ->
            handleUserMessage(voiceText)
        }
    }

    fun stopListening() {
        voiceManager.stopListening()
    }

    fun toggleTask(task: RoutineTask) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = task.copy(isCompleted = !task.isCompleted)
            repository.updateTask(updated)
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
        voiceManager.destroy()
    }
}
